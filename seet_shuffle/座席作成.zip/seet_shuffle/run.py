import openpyxl as px
from openpyxl.styles import Border, Side
import random
import os

member_dict = {
    "1" : ("浅野　友梨紀", "ｱｻﾉ ﾄﾘﾉ"),
    "2" : ("阿蘇　星侑", "ｱｿ ｾｲﾕｳ"),
    "3" : ("新山　響生", "ｱﾗﾔﾏ ｷｮｳ"),
    "4" : ("伊野　友恵", "ｲﾉ ﾄﾓｴ"),
    "5" : ("植田　歩夢", "ｳｴﾀﾞ ｱﾕﾑ"),
    "7" : ("大井　龍之介", "ｵｵｲ ﾘｭｳﾉｽｹ"),
    "8" : ("岡本　雅生", "ｵｶﾓﾄ ﾐﾔｷ"),
    "9" : ("金澤　昂太朗", "ｶﾅｻﾞﾜ ｺｳﾀﾛｳ"),
    "10" : ("金子　真奈", "ｶﾈｺ ﾏﾅ"),
    "11" : ("川越　光", "ｶﾜｺﾞｴ ﾋｶﾙ"),
    "12" : ("喜多　恭平", "ｷﾀ ｷｮｳﾍｲ"),
    "13" : ("木原　正志", "ｷﾊﾗ ﾏｻｼ"),
    "14" : ("窪田　樹", "ｸﾎﾞﾀ ｲﾂｷ"),
    "15" : ("黒田　玲矢", "ｸﾛﾀﾞ ﾚｲﾔ"),
    "16" : ("小間　翔悟", "ｺﾏ ｼｮｳｺﾞ"),
    "17" : ("駒井　宏至", "ｺﾏｲ ｺｳｼ"),
    "18" : ("島倉　友志", "ｼﾏｸﾗ ﾄﾓｼ"),
    "19" : ("洲崎　真奈花", "ｽｻｷ ﾏﾅｶ"),
    "20" : ("泉田　昌紀", "ｾﾝﾀﾞ ﾏｻｷ"),
    "21" : ("大代　浩一朗", "ﾀﾞｲﾀﾞｲ ｺｳｲﾁﾛｳ"),
    "22" : ("多胡　誠高", "ﾀｺﾞ ﾏｻﾀｶ"),
    "23" : ("田中　太郎", "ﾀﾅｶ ﾀﾛｳ"),
    "24" : ("田中　友也", "ﾀﾅｶ ﾄﾓﾔ"),
    "25" : ("谷口　智哉", "ﾀﾆｸﾞﾁ ﾄﾓﾔ"),
    "26" : ("反怖　勇希", "ﾀﾝﾎﾞ ﾕｳﾏ"),
    "27" : ("釣谷　那津", "ﾂﾘﾀﾆ ﾅﾂ"),
    "28" : ("寺林　大樹", "ﾃﾗﾊﾞﾔｼ ﾀｲｷ"),
    "29" : ("寺林　聖斗", "ﾃﾗﾊﾞﾔｼ ﾏｻﾄ"),
    "30" : ("中嶋　菊", "ﾅｶｼﾞﾏ ｷｸ"),
    "31" : ("中谷　朱里", "ﾅｶﾀﾆ ｱｶﾘ"),
    "32" : ("中村　公紀", "ﾅｶﾑﾗ ｺｳｷ"),
    "33" : ("中村　大輔", "ﾅｶﾑﾗ ﾀﾞｲｽｹ"),
    "34" : ("中村　紀香", "ﾅｶﾑﾗ ﾉﾘｶ"),
    "35" : ("野崎　真之介", "ﾉｻﾞｷ ｼﾝﾉｽｹ"),
    "36" : ("早川　颯馬", "ﾊﾔｶﾜ ｿｳﾏ"),
    "37" : ("藤井　志信", "ﾌｼﾞｲ ｼﾉﾌﾞ"),
    "38" : ("藤井　友哉", "ﾌｼﾞｲ ﾄﾓﾔ"),
    "39" : ("藤田　愛理", "ﾌｼﾞﾀ ｱｲﾘ"),
    "40" : ("藤田　壮", "ﾌｼﾞﾀ ｿｳ"),
    "41" : ("藤野　裕時", "ﾌｼﾞﾉ ﾕｳｼﾞ"),
    "42" : ("舩﨑　裕大", "ﾌﾅｻｷ ﾕｳﾀ"),
    "43" : ("舟根　あいか", "ﾌﾅﾈ ｱｲｶ"),
    "44" : ("干場　滉太", "ﾎｼﾊﾞ ｺｳﾀ"),
    "45" : ("村上　彰洋", "ﾑﾗｶﾐ ｱｷﾋﾛ"),
    "46" : ("村上　航", "ﾑﾗｶﾐ ﾜﾀﾙ"),
    "47" : ("矢後　歩海", "ﾔｺﾞ ｱﾕﾐ"),
    "48" : ("矢野　菜摘", "ﾔﾉ ﾅﾂﾐ"),
    "49" : ("山上　啓吾", "ﾔﾏｶﾞﾐ ｹｲｺﾞ"),
    "50" : ("山田　和輝", "ﾔﾏﾀﾞ ｶｽﾞｷ"),
    "51" : ("山田　涼仁", "ﾔﾏﾀﾞ ﾘｮｳｼﾞ"),
    "53" : ("四栁　翔太", "ﾖﾂﾔﾅｷﾞ ｼｮｳﾀ"),
    "54" : ("渡邊　哲平", "ﾜﾀﾅﾍﾞ ﾃｯﾍﾟｲ"),
}

def excel_writer(row,col,number):
    ws.cell(row=row,column=col).value = int(number)
    ws.cell(row=row,column=col + 1).value = member_dict[number][1]
    ws.cell(row=row + 1,column=col + 1).value = member_dict[number][0]
    ws.cell(row=row,column=col).border = Border(
        outline=True,
        top=Side(style='thin', color='00000000'),
        left=Side(style='thin', color='00000000')
    )
    ws.cell(row=row + 1,column=col).border = Border(
        outline=True,
        left=Side(style='thin', color='00000000'),
        bottom=Side(style='thin', color='00000000')
    )

def kyoutaku_newline():
    ws['J27'].border = Border(
        outline=True,
        top=Side(style='thin', color='00000000'),
        left=Side(style='thin', color='00000000'),
        bottom=Side(style='thin', color='00000000')
    )
    ws['K27'].border = Border(
        outline=True,
        top=Side(style='thin', color='00000000'),
        right=Side(style='thin', color='00000000'),
        bottom=Side(style='thin', color='00000000')
    )

# 目が悪い人の番号を入力
priority = set(["4","32"])
full_member = set([str(x) for x in range(1,55)]) - set(["6","52"]) - priority

vacancy = list()
for row in range(24,2,-3):
    for col in range(1,21,3):
        if row == 18 and col == 1:
            continue
        if row == 6 and col == 1:
            continue
        if row == 3 and (col == 1 or col == 4):
            continue
        vacancy.append((row, col))


wb = px.load_workbook('./2017_i4_seat.xlsx')
ws = wb['using']

for atnumber in priority:
    r,c = vacancy.pop(0)
    excel_writer(r,c,atnumber)

while(full_member):
    member = random.choice(list(full_member))
    full_member.remove(member)
    r,c = vacancy.pop(0)
    excel_writer(r,c,member)

kyoutaku_newline()


wb.save(f'./new_seat_{random.randint(1,100000)}.xlsx')
