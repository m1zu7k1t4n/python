# 数列からのグラフ的判定
Python3を用いてグラフ化可能かどうかを判定する。

## Usage

### Open
- terminal

### Run
Example
```sh
python graphorder_count.py input1.csv input2.csv
```
引数に入力したcsvファイルを判定する

```sh
python graphorder_count.py
```
ファイルの存在に関わらずデフォルト設定としてinput.csvを判定する。